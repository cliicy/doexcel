#!/bin/bash

cfg_file=sysbench-cfg/benchmark.cfg
sh 1_prep_dev.sh ${cfg_file}
sh 2_initdb.sh ${cfg_file} 
sh 3_run.sh ${cfg_file} 
