#!/bin/bash

source ../lib/common-lib
generate_csv $1
