SELECT * FROM pg_stat_activity
