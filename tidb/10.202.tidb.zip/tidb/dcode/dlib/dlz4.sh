#!/bin/bash

source ./dlz4-lib

compress_dbfiles $1 $2
