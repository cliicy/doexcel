#!/bin/bash

source ./dlz4-lib

decompress_dbfiles $1 $2
