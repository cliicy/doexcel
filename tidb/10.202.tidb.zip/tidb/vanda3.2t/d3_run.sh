#! /bin/bash

cfg_file=$1
if [ "${cfg_file}" = "" ]; then echo -e "Usage:\n\t3_run.sh cfg_file"; exit 1; fi
if [ ! -e ${cfg_file} ]; then echo "can't find configuration file [${cfg_file}]", exit 2; fi
source ${cfg_file}

# output_dir will be used in fio.sh, so make it global
if [ "${output_dir}" == "" ];
then
        export output_dir=${result_dir}/${logfolder}-`date +%Y%m%d_%H%M%S`${case_id}
fi

echo "test output will be saved in ${output_dir}"
if [ ! -e ${output_dir} ]; then mkdir -p ${output_dir}; fi

# collect TiDB startup options / configuration / test script
cp $0 ${output_dir}
cp ${cfg_file} ${output_dir}
cp ${app_datadir_tikv}/last_tikv.toml ${output_dir}

source ../lib/common-lib
source ../lib/bench-lib
source ../lib/tidb-lib

collect_sys_info ${output_dir} ${css_status}

echo "export output_dir=${output_dir}" > ./output.dir
#collect some extra information
client_cmd="${cli_access} -h ${host} -P ${cli_port} -u ${cli_usr} -D ${cli_db}"
${client_cmd} -N -e 'show variables' > ${output_dir}/tidb_var.log

echo "will run workload(s) ${workload_set}"
lastwl=`echo ${workload_set} | awk '{print $NF}'`
for workload in ${workload_set};
    do
        echo "run workload ${workload}"
	cmd="run"
        # workload friendly name. it will be used in fio.sh, so make it global
        export workload_fname=${workload}
        if [ "prepare" == "${workload}" ]; then cmd="prepare"; workload="oltp_common"; workload_fname="prepare"; fi
        echo -e "sfx_message starts at: " `date +%Y-%m-%d\ %H:%M:%S` "\n"  > ${output_dir}/${workload_fname}.sfx_message
        sudo chmod 666 /var/log/sfx_messages;
	tail -f -n 0 /var/log/sfx_messages >> ${output_dir}/${workload_fname}.sfx_message &
        echo $! > ${output_dir}/tail.${workload_fname}.pid
        echo "iostat start at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.iostat
        tail -f -n 0 ${app_log} > ${output_dir}/${workload_fname}.${app}.log &
        echo $! > ${output_dir}/tail.${workload_fname}.${app}.log.pid
        echo "tidb slow log start at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.tidb_slow_log
        tail -f -n 0 ${tidb_slowlog} >> ${output_dir}/${workload_fname}.tidb_slow_log &
        echo $! > ${output_dir}/tail.${workload_fname}.${app}.tidb_slow_log.pid
        echo "tikv log start at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.tikv.log
        tail -f -n 0 ${app_tikvlog} >> ${output_dir}/${workload_fname}.tikv.log &
        echo $! > ${output_dir}/tail.${workload_fname}.${app}.tikv.log.pid
        echo "tidb log start at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.tidb.log
        tail -f -n 0 ${app_tidblog} >> ${output_dir}/${workload_fname}.tidb.log &
        echo $! > ${output_dir}/tail.${workload_fname}.${app}.tidb.log.pid

        echo "tikv DB LOG start at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.DBLOG
        tail -f -n 0 ${tikv_DBLOG} >> ${output_dir}/${workload_fname}.DBLOG &
        echo $! > ${output_dir}/tail.${workload_fname}.${app}.DBLOG.pid
        
        #tikv_pid=`ps -ef | grep -v grep |grep tikv-server | awk '{print $2}'`
        #echo "top -H -p ${tikv_pid} -d ${rpt_interval} > ${output_dir}/${workload_fname}.tikv_pid.cpu & "
        #top -b -H -p  ${tikv_pid} -d ${rpt_interval} > ${output_dir}/${workload_fname}.cpu & 
        top -b -d ${rpt_interval} > ${output_dir}/${workload_fname}.cpu & 
        echo $! > ${output_dir}/${workload_fname}.cpu.pid
        

        # try to keep existing result file
        if [ -e ${output_dir}/${workload_fname}.result ];
        then
                mv ${output_dir}/${workload_fname}.result ${output_dir}/${workload_fname}-`date +%Y%m%d_%H%M%S`.result
        fi
        echo "${workload_fname} starts at: " `date +%Y-%m-%d\ %H:%M:%S` > ${output_dir}/${workload_fname}.result

        iostat -txdmc ${rpt_interval} ${disk} >> ${output_dir}/${workload_fname}.iostat &
        echo $! > ${output_dir}/${workload_fname}.iostat.pid

        if [ "${cmd}" == "run" ];
        then
                #start_blk_trace ${output_dir} ${workload_fname} ${disk} 120 &
                ps -ef | grep blktrace | grep -v grep | awk '{print $2}' | xargs kill -15
        fi

        time sysbench \
                --db-driver=mysql --mysql-db=${dbname} --mysql-user=${cli_usr} \
                --mysql-host=${host} --mysql-port=${cli_port} \
                --report-interval=${rpt_interval} --time=${run_time} --threads=${threads} \
                --percentile=${percentile} ${sysbench_dir}/${workload}.lua\
                --warmup-time=${warmup_time} --rand-type=${rand_type} --histogram=on \
                --tables=${table_count} --table-size=${table_size} --point_selects=0 --distinct_ranges=0 --simple_ranges=0 \
                --create-table-options="${create_tbl_opt}" --sum_ranges=10000 --range_size=10000 \
                --create_index_options="${create_tbl_opt}" \
                --table-data-src-file=${table_data_src_file} \
                ${cmd} \
                >> ${output_dir}/${workload_fname}.result

        ps aux | grep sysbench | grep -v grep >> ${output_dir}/${workload_fname}.cmd 

        du --block-size=1G ${app_datadir_root} > ${output_dir}/${workload_fname}.dbsize
        cat /sys/block/${dev_name}/sfx_smart_features/sfx_capacity_stat >> ${output_dir}/${workload_fname}.dbsize

        echo -e "\nsfx_messages ends at: `date +%Y-%m-%d_%H:%M:%S`\n"  >> ${output_dir}/${workload_fname}.sfx_message
        echo ${output_dir}/tail.${workload_fname}.pid
        kill `cat ${output_dir}/tail.${workload_fname}.pid`
        rm -f ${output_dir}/tail.${workload_fname}.pid
        echo -e "\niostat ends at: " `date +%Y-%m-%d_%H:%M:%S` >> ${output_dir}/${workload_fname}.iostat
        echo -e "\n${workload_fname}" "\nends at: " "`date +%Y-%m-%d_%H:%M:%S`" >> ${output_dir}/${workload_fname}.result
        echo ${output_dir}/${workload_fname}.iostat.pid
        kill `cat ${output_dir}/${workload_fname}.iostat.pid`
        rm -f ${output_dir}/${workload_fname}.iostat.pid
        kill `cat ${output_dir}/tail.${workload_fname}.${app}.log.pid`
        rm -f ${output_dir}/tail.${workload_fname}.${app}.log.pid
        echo "tidb slow log ends at: " `date +%Y-%m-%d\ %H:%M:%S` >> ${output_dir}/${workload_fname}.tidb_slow_log
        kill `cat ${output_dir}/tail.${workload_fname}.${app}.tidb_slow_log.pid`
        rm -f ${output_dir}/tail.${workload_fname}.${app}.tidb_slow_log.pid
        echo "tidb log ends at: " `date +%Y-%m-%d\ %H:%M:%S` >> ${output_dir}/${workload_fname}.tidb.log
        kill `cat ${output_dir}/tail.${workload_fname}.${app}.tidb.log.pid`
        rm -f ${output_dir}/tail.${workload_fname}.${app}.tidb.log.pid
        echo "tikv log ends at: " `date +%Y-%m-%d\ %H:%M:%S` >> ${output_dir}/${workload_fname}.tikv.log
        kill `cat ${output_dir}/tail.${workload_fname}.${app}.tikv.log.pid`
        rm -f ${output_dir}/tail.${workload_fname}.${app}.tikv.log.pid

        echo "tikv DBLOG ends at: " `date +%Y-%m-%d\ %H:%M:%S` >> ${output_dir}/${workload_fname}.DBLOG
        kill `cat ${output_dir}/tail.${workload_fname}.${app}.DBLOG.pid`
        rm -f ${output_dir}/tail.${workload_fname}.${app}.DBLOG.pid

        kill `cat ${output_dir}/${workload_fname}.tikv_pid.cpu.pid`
        rm -f ${output_dir}/${workload_fname}.cpu.pid
        ps -ef | grep top | grep -v grep | awk '{print $2}' | xargs kill -9

        sleep ${sleep_after_case}
    done

cp ${tikv_DBLOG} ${output_dir}

generate_csv ${output_dir}
get_dbsize_new ${output_dir}

ssd_name=$(basename "$PWD")
get_rocksdb_cpu ${output_dir}
gen_benchinfo_tidb ${ssd_name} ${table_count}.${table_size} ${output_dir}

