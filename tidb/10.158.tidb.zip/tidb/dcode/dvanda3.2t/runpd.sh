#!/bin/bash

cfg_file=$1
if [ "$1" = "" ]; then echo -e "Usage:\n\t2_initdb.sh cfg_file"; exit 1; fi
if [ ! -e ${cfg_file} ]; then echo "can't find configuration file [${cfg_file}]", exit 2; fi
source ${cfg_file}

##start pd-server
#${app_basedir}/bin/pd-server --data-dir=${app_datadir_pd} --log-file=${app_pdlog} &

docker run -d --name pd1 \
  -p 2379:2379 \
  -p 2379:2380 \
  -v /etc/localtime:/etc/localtime:ro \
  -v /opt/data:/opt/data \
  pingcap/pd:latest \
  --name="pd1" \
  --data-dir=${app_datadir_pd} \
  --client-urls="http://127.0.0.1:2379" \
  --advertise-client-urls="http://127.0.0.1:2379" \
  --peer-urls="http://127.0.0.1:2380" \
  --advertise-peer-urls="http://127.0.0.1:2380" \
  --initial-cluster="pd1=http://127.0.0.1:2380"


