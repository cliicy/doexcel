pushd /home/tcn/software/vanda/rc_3.0.4.0-r49228/bin_pkg/centos7.5/sfx_qual_suite 
sudo ./initcard.sh --blk --cl
sudo sh ./sfx-status
popd
