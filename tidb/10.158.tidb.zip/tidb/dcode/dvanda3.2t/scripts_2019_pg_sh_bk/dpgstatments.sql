select * from warehouse1;
