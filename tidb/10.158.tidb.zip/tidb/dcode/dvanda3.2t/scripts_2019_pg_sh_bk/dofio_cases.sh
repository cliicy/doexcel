#!/bin/bash

sh fs_fio_dev.sh sysbench-cfg/benchmark.cfg;sh raw_fio_dev.sh sysbench-cfg/benchmark.cfg

