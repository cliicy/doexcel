#!/bin/bash

pushd /opt/app/benchmark/tidb/vanda3.2t
sh tidb_run-case.sh 
popd

