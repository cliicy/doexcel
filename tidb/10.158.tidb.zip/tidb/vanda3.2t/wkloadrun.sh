#!/bin/bash

sh stop.sh
sed -i s/"max-sub-compactions = 18"/"max-sub-compactions = 1"/ ./tidb-cfg/last_tikv.toml
sed -i s/"max-write-buffer-number = 10"/"max-write-buffer-number = 5"/ ./tidb-cfg/last_tikv.toml
sed -i s/"max-background-jobs = 10"/"max-background-jobs = 6"/ ./tidb-cfg/last_tikv.toml

cfgfile=./sysbench-cfg/benchmark.cfg
sed -i s/workload_set=prepare/'workload_set=\"oltp_read_only oltp_update_non_index oltp_update_index oltp_point_select oltp_read_write oltp_write_only\"'/ ${cfgfile}

sh start.sh ${cfgfile}
./3_run.sh ${cfgfile} 

# restore to the origianl setting for prepare
sed -i s/"max-sub-compactions = 1"/"max-sub-compactions = 18"/ ./tidb-cfg/last_tikv.toml
sed -i s/"max-write-buffer-number = 5"/"max-write-buffer-number = 10"/ ./tidb-cfg/last_tikv.toml
sed -i s/"max-background-jobs = 6"/"max-background-jobs = 10"/ ./tidb-cfg/last_tikv.toml
sed -i s/'workload_set=\"oltp_read_only oltp_update_non_index oltp_update_index oltp_point_select oltp_read_write oltp_write_only\"'/workload_set=prepare/ ${cfgfile}

# do intel
sleep 120
sh stop.sh
pushd /opt/app/benchmark/tidb/intel3.2t
sh seperate_tidb_run.sh
popd


#wkdlist='\"oltp_read_only oltp_update_non_index oltp_update_index oltp_point_select oltp_read_write oltp_write_only\"'
#sed -i s/workload_set=prepare/'workload_set=${wkdlist}'/ ${cfgfile} 
#sed -i s/'workload_set=\"${wkdlist}\"'/workload_set=prepare/ ${cfgfile} 
